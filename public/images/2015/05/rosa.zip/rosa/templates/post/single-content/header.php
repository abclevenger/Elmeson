<?php
// nothing here for the moment
?>

<header class="article__header">
	<h1 class="article__title"><?php the_title(); ?></h1>
	<hr class="separator"/>
	<?php get_template_part( 'templates/post/single-content/featured-classic/image'); ?>
</header><!-- .article__header -->