<?php
/**
 * Content wrappers
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */
?>

                    </section><!-- .page__content -->
                </div><!-- .container -->
            </section><!-- .article__content -->
        </article><!-- .post-## -->