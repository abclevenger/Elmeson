<?php defined( 'ABSPATH' ) or die; ?>

<h3>Download Failed!</h3>

<p>The system has encountered an error while trying to download required files.</p>

<ul style="list-style-type: square; padding: 0 25px">
	<li>Unrecognized download method requested. (please contact support)</li>
</ul>
