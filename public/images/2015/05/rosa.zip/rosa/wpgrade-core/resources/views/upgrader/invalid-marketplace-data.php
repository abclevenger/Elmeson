<?php defined( 'ABSPATH' ) or die; ?>

<h3>Invalid TeamForest/Envato Marketplace Data</h3>

<p>Your TeamForest/Envato Marketplace data appears to be invalid.</p>

<p><i>Please re-check <a href="<?php echo admin_url( 'admin.php?page=' . wpgrade::shortname() . '_options&tab=8' ) ?>">your
			marketplace data</a>.</i></p>
