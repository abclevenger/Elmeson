<?php defined( 'ABSPATH' ) or die; ?>

<h3>Unknown Server Error</h3>

<p>The system has encountered an unknown server error.</p>

<p><i>Please contact support.</i></p>