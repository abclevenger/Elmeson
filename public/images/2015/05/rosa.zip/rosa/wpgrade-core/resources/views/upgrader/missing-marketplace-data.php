<?php defined( 'ABSPATH' ) or die; ?>

<h3>Missing TeamForest/Envato Marketplace Data</h3>

<p>Your TeamForest/Envato Marketplace data doesn't appear to be set.</p>

<p>Please go to <span class="syspath-help">Theme Options &raquo; <a
			href="<?php echo admin_url( 'admin.php?page=' . wpgrade::shortname() . '_options&tab=8' ) ?>">Utilities</a></span>
	and add your username and secret api key.</p>
