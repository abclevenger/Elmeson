<?php defined( 'ABSPATH' ) or die; ?>

<h3>Download Failed!</h3>

<p>The system has encountered an error while trying to download required files.</p>

<p>The upgrade process has been halted. No data has been lost.</p>
