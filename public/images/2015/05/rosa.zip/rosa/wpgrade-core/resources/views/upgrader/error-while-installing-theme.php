<?php defined( 'ABSPATH' ) or die;
/** @var array $error_messages */
?>

<h3>Error while trying to Install theme!</h3>

<p>The system has encountered some error while trying to install the theme:</p>

<ul style="list-style-type: square; padding: 0 25px">
	:error_list
</ul>

<hr/>

<p><i>If you continue to experience problems, please refer to the included documentation or contact support.</i></p>
