<?php defined( 'ABSPATH' ) or die; ?>

<h3>Critical Error While Analysing System</h3>

<p>The system has encountered system error while trying to analyze download options.</p>

<p>Please refer to the included documentation for server requirements.</p>

<p><i>If you continue to experience problems, please contact support.</i></p>
