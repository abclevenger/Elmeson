<?php defined( 'ABSPATH' ) or die; ?>

<h3>Critical Error while trying to create backup</h3>

<p>The system has encountered an error while trying to backup files.</p>

<p>Potential causes include old wordpress version, faulty PHP configuration, etc.</p>

<p><i>If you continue to experience problems, please refer to the included documentation or contact support.</i></p>
