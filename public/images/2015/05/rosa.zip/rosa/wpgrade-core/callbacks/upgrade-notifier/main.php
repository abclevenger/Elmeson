<?php

/**
 * The notifier page
 */
function update_notifier() {
	include wpgrade::corepartial( 'update-notifier' . EXT );
}
