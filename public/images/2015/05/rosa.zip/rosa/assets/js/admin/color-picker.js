(function ($) {

	jQuery(document).ready(function ($) {
		$('.colorpicker').wpColorPicker();
	});

})(jQuery);